package kr.co.dong.service;

import kr.co.dong.DTO.BuyDTO;

public interface BuyService {
    public int addBuy(BuyDTO buy);
}
