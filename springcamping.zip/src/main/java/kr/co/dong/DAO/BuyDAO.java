package kr.co.dong.DAO;

import kr.co.dong.DTO.BuyDTO;

public interface BuyDAO {
    public int insertBuy(BuyDTO buy);
}
